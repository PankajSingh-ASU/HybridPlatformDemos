IDE Recipes
===============

