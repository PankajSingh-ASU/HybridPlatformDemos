This is the sample code for the iOS recipe for adding app links to an Android project.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/cross-platform/app-links/app-links-android/)
