This is the sample code for the Android recipe for recording audio.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/media/audio/record_audio)
