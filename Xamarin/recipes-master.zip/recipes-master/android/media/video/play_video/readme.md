This is the sample code for the Android recipe for playing video.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/media/video/play_video)
