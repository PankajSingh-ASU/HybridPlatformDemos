This is the sample code for the Android recipe for recording video.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/media/video/record_video)
