Android Resources Recipes
===============

