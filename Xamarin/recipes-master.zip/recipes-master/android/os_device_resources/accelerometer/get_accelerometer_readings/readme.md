This is the sample code for the Android recipe for reading accelerometer data.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/os_device_resources/accelerometer/get_accelerometer_readings)
