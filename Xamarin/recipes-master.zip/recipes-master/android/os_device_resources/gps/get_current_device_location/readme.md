This is the sample code for the Android recipe for getting the current device location.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/os_device_resources/gps/get_current_device_location)
