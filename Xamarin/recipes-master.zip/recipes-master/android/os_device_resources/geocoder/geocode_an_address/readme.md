This is the sample code for the Android recipe for geocoding an address.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/os_device_resources/geocoder/geocode_an_address)
