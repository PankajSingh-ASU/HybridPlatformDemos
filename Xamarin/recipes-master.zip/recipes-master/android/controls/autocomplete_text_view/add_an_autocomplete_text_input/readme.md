This is the sample code for the Android recipe for adding an autocomplete text view to your app.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/controls/autocomplete_text_view/add_an_autocomplete_text_input/)
