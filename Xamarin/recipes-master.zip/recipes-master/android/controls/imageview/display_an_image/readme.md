This is the sample code for the Android recipe for displaying an image with an imageview.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/controls/imageview/display_an_image/)
