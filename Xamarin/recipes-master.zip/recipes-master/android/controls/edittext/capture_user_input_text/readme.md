This is the sample code for the Android recipe for adding an edittext view.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/controls/edittext/capture_user_input_text/)
