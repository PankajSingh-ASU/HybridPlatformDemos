This is the sample code for the Android recipe for creating an image button.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/controls/imagebutton/create_an_imagebutton/)
