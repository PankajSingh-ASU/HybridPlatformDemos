This is the sample code for the Android recipe for adding a DatePicker to your app.

[See the guide at developer.xamarin.com](http://developer.xamarin.com/guides/android/user_interface/date_picker/)
