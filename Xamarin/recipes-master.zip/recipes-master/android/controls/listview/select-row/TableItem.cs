namespace SelectRow
{
    public class TableItem
    {
        public string Heading { get; set; }
        public string SubHeading { get; set; }
        public int ImageResourceId { get; set; }
    }
}