This is the sample code for the Android recipe for loading a web page with a webview.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/controls/webview/load_a_web_page/)
