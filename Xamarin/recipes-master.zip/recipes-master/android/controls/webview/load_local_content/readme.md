This is the sample code for the Android recipe for displaying local content in a webview.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/controls/webview/load_local_content/)
