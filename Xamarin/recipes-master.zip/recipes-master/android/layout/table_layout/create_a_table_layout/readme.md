This is the sample code for the Android recipe for creating a table layout.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/layout/table_layout/create_a_table_layout)
