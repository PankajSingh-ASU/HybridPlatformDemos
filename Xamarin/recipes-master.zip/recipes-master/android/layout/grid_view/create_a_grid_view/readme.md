This is the sample code for the Android recipe for creating a grid view.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/layout/grid_view/create_a_grid_view)
