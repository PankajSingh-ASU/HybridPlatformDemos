Android General Recipes
===============

