This is the sample code for the Android recipe for creating a database with ADO.NET.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/data/databases/adonet/)
