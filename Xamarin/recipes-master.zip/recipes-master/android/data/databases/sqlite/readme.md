This is the sample code for the Android recipe for creating a database using sqlite.Net.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/data/databases/sqlite/)
