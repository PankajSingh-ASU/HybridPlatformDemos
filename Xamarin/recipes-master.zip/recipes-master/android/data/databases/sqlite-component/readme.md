This is the sample code for the Android recipe for creating a database using the sqlite.Net component.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/data/databases/sqlite-component/)
