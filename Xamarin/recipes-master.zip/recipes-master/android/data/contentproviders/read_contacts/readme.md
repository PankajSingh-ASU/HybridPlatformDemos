This is the sample code for the Android recipe for reading contacts.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/data/contentproviders/read_contacts/)
