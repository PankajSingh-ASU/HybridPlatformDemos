This is the sample code for the Android recipe for creating a custom contacts adapter.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/data/adapters/create_a_custom_adapter_for_contacts/)
