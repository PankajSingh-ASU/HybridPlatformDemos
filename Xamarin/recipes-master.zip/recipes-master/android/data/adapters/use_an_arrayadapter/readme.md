This is the sample code for the Android recipe for using an array adapter.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/data/adapters/use_an_arrayadapter/)
