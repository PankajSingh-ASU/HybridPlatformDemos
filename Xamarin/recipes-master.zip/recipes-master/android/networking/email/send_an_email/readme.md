This is the sample code for the Android recipe for sending email.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/networking/email/send_an_email)
