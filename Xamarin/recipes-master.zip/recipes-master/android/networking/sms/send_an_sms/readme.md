This is the sample code for the Android recipe for sending an SMS message.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/networking/sms/send_an_sms)
