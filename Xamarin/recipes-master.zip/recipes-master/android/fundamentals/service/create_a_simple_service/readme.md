This is the sample code for the Android recipe for creating a service.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/fundamentals/service/create_a_simple_service)
