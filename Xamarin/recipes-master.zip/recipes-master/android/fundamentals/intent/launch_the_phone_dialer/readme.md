This is the sample code for the Android recipe for using an intent to launch the phone dialer.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/fundamentals/intent/launch_the_phone_dialer)
