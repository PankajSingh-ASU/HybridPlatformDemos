This is the sample code for the Android recipe for using an intent to start the map application.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/fundamentals/intent/launch_the map_application)
