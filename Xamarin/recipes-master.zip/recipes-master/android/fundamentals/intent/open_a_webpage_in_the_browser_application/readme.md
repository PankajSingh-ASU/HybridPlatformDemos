This is the sample code for the Android recipe for using an intent to launch a web page using the browser application.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/fundamentals/intent/open_a_webpage_in_the_browser_application)
