This is the sample code for the Android recipe for passing data between activities.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/fundamentals/activity/pass_data_between_activity/)
