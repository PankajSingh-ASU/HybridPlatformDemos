This is the sample code for the Android recipe for starting an activity to get a result.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/fundamentals/activity/start_activity_for_result)
