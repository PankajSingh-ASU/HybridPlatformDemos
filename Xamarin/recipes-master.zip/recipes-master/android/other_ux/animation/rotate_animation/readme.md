This is the sample code for the Android recipe for rotating an image.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/animation/rotate_animation)
