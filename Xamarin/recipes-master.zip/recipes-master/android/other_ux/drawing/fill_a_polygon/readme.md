This is the sample code for the Android recipe for filling a polygon.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/drawing/fill_a_polygon)
