This is the sample code for the Android recipe for blurring an image with renderscript.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/drawing/blur_an_image_with_renderscript)
