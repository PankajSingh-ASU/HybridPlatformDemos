This is the sample code for the Android recipe for drawing 2d graphics.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/drawing/draw_2d_graphics)
