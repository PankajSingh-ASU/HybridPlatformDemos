This is the sample code for the Android recipe for displaying a stream from the camera using a texture view.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/textureview/display_a_stream_from_the_camera)
