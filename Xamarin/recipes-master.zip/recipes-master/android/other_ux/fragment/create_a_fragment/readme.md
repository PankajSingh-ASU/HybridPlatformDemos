This is the sample code for the Android recipe for creating a fragment.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/fragment/create_a_fragment)
