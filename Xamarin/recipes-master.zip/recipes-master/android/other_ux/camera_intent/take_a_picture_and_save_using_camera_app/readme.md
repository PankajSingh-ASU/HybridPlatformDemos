This is the sample code for the Android recipe for taking a picture and saving it using the camera app.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/camera_intent/take_a_picture_and_save_using_camera_app)
