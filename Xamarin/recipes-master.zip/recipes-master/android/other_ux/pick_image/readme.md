This is the sample code for the Android recipe for picking an image.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/pick_image)
