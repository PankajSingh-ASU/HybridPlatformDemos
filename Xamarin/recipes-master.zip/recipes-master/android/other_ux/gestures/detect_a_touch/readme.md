This is the sample code for the Android recipe for detecting touch.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/gestures/detect_a_touch)
