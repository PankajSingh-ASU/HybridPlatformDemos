This is the sample code for the Android recipe for creating a gesture listener.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/other_ux/gestures/create_a_gesture_listener)
