Resources Recipes
===============

