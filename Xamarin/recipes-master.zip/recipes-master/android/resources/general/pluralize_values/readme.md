This is the sample code for the Android recipe for pluralizing values.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/resources/general/pluralize_values)
