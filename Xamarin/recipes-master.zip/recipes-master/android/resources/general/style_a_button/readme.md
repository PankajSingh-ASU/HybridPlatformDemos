This is the sample code for the Android recipe for styling a button.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/resources/general/style_a_button)
