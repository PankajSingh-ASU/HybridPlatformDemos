This is the sample code for the Android recipe for detecting a device's screen size.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/android/resources/device_specific/detect_screen_size)
